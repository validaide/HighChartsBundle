/*******************************************************************************
 *
 * Highcharts Export Server
 *
 * Copyright (c) 2016-2022, Highsoft
 *
 * Licenced under the MIT licence.
 *
 * Additionally a valid Highcharts license is required for use.
 *
 * See LICENSE file in root for details.
 ******************************************************************************/

// @format

const fs = require('fs');
const config = require('./lib/schemas/config.js');

/*
 * This script will bake the README from contents in docs.
 * The main idea is to avoid having to keep the various config options and
 * so on in sync with the code, and instead generate that from the code.
 */


const resolveArg = (arg) => {
  const path = arg.split('.');
  let res = config.defaultConfig[path[0]];

  for (let i = 1; i < path.length; ++i) {
    res = res[path[i]];
  }

  return res;
};

const descConfig = (obj, level) => {
  level = level || 1;

  if (!obj) {
    return false;
  }

  if (level > 2) {
    return false;
  }

  const res = {};

  Object.keys(obj).forEach(ns => {

    const nsObj = {};
    res[ns] = nsObj;

    Object.keys(obj[ns]).forEach(k => {
      if (typeof obj[ns][k].value !== 'undefined') {
        nsObj[k] = obj[ns][k].value ; // + ' (' + obj[ns][k].description + ')';
      } else if (ns && k) {
        nsObj[ns] = nsObj[ns] || {};
        nsObj[ns] = descConfig(obj[ns], level + 1);
      }
    });
  });

  return res;
};

const bakeFlags = () => `
# Configuration

There are three main ways of loading configurations: 
  * Through command line arguments
  * By loading a JSON file
  * By supplying environment variables

...or any combination of the three.

## Command Line Arguments

To supply command line arguments, add them as flags when running the application:
\`highcharts-export-server --flag1 value --flag2 value ....\`

*Available options:*
${Object.keys(config.nestedArgs).map(a => 
  `- \`--${a}\`: ${resolveArg(config.nestedArgs[a]).description} (defaults to \`${resolveArg(config.nestedArgs[a]).value}\`)`
).join('\n')}

## Loading JSON Configs

To load JSON configuration files start the export server by using the \`--loadConfig <filepath>\` option, e.g. \`highcharts-export-server --loadConfig path/to/my/config.json\`

The format, with its default values are as follows:

\`\`\`
${JSON.stringify(descConfig(config.defaultConfig), undefined, '  ')}
\`\`\`

## Environment Variables

These are set as variables in your environment. On Linux, use e.g. \`export\`.
If there's an \`.env\` file in the current working directory, variables will also be loaded from there.

${config.envVars.map(e => 
  `- \`${e.name}\`: ${e.description}`
).join('\n')}

`
;

console.log(bakeFlags());
